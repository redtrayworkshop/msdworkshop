Provides a shortcode API and basic shortcodes through Drupal filters.

Initial works based on the Wordpress Shortcode API but I rewrote it for Drupal and solved the nested tag problem. Now you can nest tags (same tags too) no need special recursion handling.

All tags are themeable and new tags can be provided by other modules.